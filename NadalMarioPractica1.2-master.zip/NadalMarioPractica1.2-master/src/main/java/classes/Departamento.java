package classes;

import jakarta.xml.bind.annotation.*;

import java.util.List;

@XmlType(propOrder = {"nombre","localidad"})
@XmlAccessorType (XmlAccessType.NONE)
public class Departamento {
    private int id;
    private String nombre;
    private String localidad;
    private List<Empleado> empleadosDep;

    @XmlElement(name = "nombre")
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    @XmlElement(name ="localidad")
    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }
    @XmlAttribute(name="id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    //Ponemos esta anotacion para que JaxB detecte que no se debe poner en el xml
    @XmlTransient
    public List<Empleado> getEmpleadosDep() {
        return empleadosDep;
    }

    public void setEmpleadosDep(List<Empleado> empleadosDep) {
        this.empleadosDep = empleadosDep;
    }
}
