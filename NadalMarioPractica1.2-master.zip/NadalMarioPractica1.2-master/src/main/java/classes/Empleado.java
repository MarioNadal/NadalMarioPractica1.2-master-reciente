package classes;

import jakarta.xml.bind.annotation.*;

import java.util.Date;

@XmlRootElement(name = "empleado")
@XmlType(propOrder = {"nombre", "sueldo", "agno", "antig"})
@XmlAccessorType (XmlAccessType.NONE)
public class Empleado {
    public String nombre;
    public int sueldo;
    public int agno;
    public Date antig;
    public int idDep;

    public Empleado() {
    }

    public Empleado(String nombre, int sueldo, int agno, Date antig) {
        this.nombre = nombre;
        this.sueldo = sueldo;
        this.agno = agno;
        this.antig = antig;
    }

    @XmlTransient
    public int getIdDep() {
        return idDep;
    }

    public void setDepartamento(int departamento) {
        this.idDep = departamento;
    }
    @XmlElement(name = "nombre")
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    @XmlElement(name = "sueldo")
    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }
    @XmlElement(name = "añoNac")
    public int getAgno() {
        return agno;
    }

    public void setAgno(int añoNacimiento) {
        this.agno = añoNacimiento;
    }
    @XmlElement(name="antigüedad")
    public Date getAntig() {
        return antig;
    }

    public void setAntig(Date antig) {
        this.antig = antig;
    }
}
