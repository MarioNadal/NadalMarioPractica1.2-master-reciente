import classes.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;

import libs.Leer;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.MalformedInputException;
import java.nio.file.NoSuchFileException;
import java.time.Instant;
import java.util.*;

import java.nio.file.Files;
import java.nio.file.Path;

public class main {
    public static void main (String[] args){
        ArrayList<Empleado> empleados = new ArrayList<>();
        Departamentos departamentos = leerDepartamentos();
        String guiones = "-".repeat(20);
        int menu;
        boolean salir = false;
        do {
            System.out.println(guiones);
            System.out.println("1. Pedir Empleados");
            System.out.println("2. Leer Departamentos");
            System.out.println("3. Asignar cada empleado Departamento");
            System.out.println("4. Leer JSON");
            System.out.println("5. Toda la información de la empresa XML o JSON");
            System.out.println("0. Salir");
            System.out.println(guiones);
            menu = libs.Leer.introduceEntero("Introduce el número del menú: ");
            System.out.println(guiones);

            switch (menu) {
                case 5 -> todaLaInformacionEmpresa(empleados, departamentos);
                case 4 -> leerNuevosEmpleadosJSON(empleados, departamentos);
                case 3 -> asignarCadaEmpleadoDepartamento(empleados, departamentos);
                case 2 -> departamentos = leerDepartamentos();
                case 1 -> pedirEmpleados(empleados);
                case 0-> salir = true;
                default -> System.out.println("Ese número no esta en el menú, introduzca un número del menu.");
            }
        } while (!salir);
    }

    private static void todaLaInformacionEmpresa(List<Empleado> empleados, Departamentos departamentos) {
        String guiones = "-".repeat(20);
        int menu;
        boolean salir = false;
        do {
            System.out.println(guiones);
            System.out.println("1. Toda la información de la empresa en XML");
            System.out.println("2. Toda la información de la empresa en JSON");
            System.out.println("0. Salir");
            System.out.println(guiones);
            menu = Leer.introduceEntero("Introduzca número del tipo de archivo de la información de la empresa que desea recibir");
         switch (menu){
             case 1 -> XMLInformacionEmpresa(empleados,departamentos);
             case 2 -> JSONInformacionEmpresa(empleados,departamentos);
             case 0 -> salir = true;
             default -> System.out.println("Ese número no esta en el menú, introduzca un número del menu.");
         }
        }while(!salir);
    }

    private static void JSONInformacionEmpresa(List<Empleado> empleados, Departamentos departamentos) {
        Path p = Path.of("target/empresa.json");
        // Generar un JSON que incluye la información de todos los departamentos y sus empleados
        GsonBuilder gsonBuilder = new GsonBuilder();
        //opcion de indentacion correcta para json
        Gson gson = gsonBuilder.setPrettyPrinting().create();
        String jsonListaDepartamentos = gson.toJson(departamentos);
        try{
            Files.writeString(p, jsonListaDepartamentos);
        }catch(IOException ex){
            System.out.println("Error al escribir el json");
        }
    }

    private static void XMLInformacionEmpresa(List<Empleado> empleados, Departamentos departamentos) {
        for (Departamento departamento : departamentos.getDepartamentos()){
        }
        try {
            JAXBContext contexto = JAXBContext.newInstance(Departamentos.class, Departamento.class, Empleado.class);
            //pasar a XML --> marshallingM
            Marshaller marshaller = contexto.createMarshaller();
            //damos formato a la salida
            marshaller.setProperty(marshaller.JAXB_FORMATTED_OUTPUT, true);
            Path p = Path.of("target/empresa.xml");
            if (libs.CheckFiles.ficheroEscribible(p)) {
                marshaller.marshal(departamentos, p.toFile());
            }
        } catch (JAXBException e) {
            System.out.println("La clase seleccionada no permite usar JAXB" + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void leerNuevosEmpleadosJSON(List<Empleado> empleados, Departamentos departamentos) {
        Path p = Path.of("src/main/resources/nuevosEmpleados.json");
        String textoJsonEmpleados = leerFichero(p);
        Gson gson = new Gson();
        Empleado[] empleadosJson = gson.fromJson(textoJsonEmpleados, Empleado[].class);
        Date hoy = Date.from(Instant.now());
            for (Empleado empleado : empleadosJson) {
                empleado.setAntig(hoy);
                for (Departamento departamento : departamentos.getDepartamentos()) {
                    if (Objects.equals(departamento.getId(), empleado.getIdDep())) {
                        departamento.getEmpleadosDep().add(empleado);
                    }
                }
            }
    }


    private static String leerFichero(Path p) {
        StringBuilder texto = new StringBuilder();
        if (Files.exists(p)&& !Files.isDirectory(p)) {
            try {
                for (String s : Files.readAllLines(p)) {
                    texto.append(s);
                }
            }
            catch(FileNotFoundException e) {
                System.out.println("No existe");
            }catch(MalformedInputException e) {
                System.out.println("Comprueba que la codificación del archivo sea UTF-8");
            }catch (NoSuchFileException e) {
                System.out.println("El archivo no existe");
            }catch (IOException e) {
                e.printStackTrace();
            }
        }
        return texto.toString();
    }

    private static Departamentos asignarCadaEmpleadoDepartamento(List<Empleado> empleados, Departamentos departamentos) {
        boolean salir = false;
        //Recorremos toda la lista empleados dependiendo de su tamaño
        for(Empleado empleado: empleados){
            do{
                //Sacamos todos los nombre de los departamentos encontrados
                System.out.println("Lista de departamentos: ");
                for(int y=1;y<=departamentos.getDepartamentos().size();y++){
                    System.out.println("\t"+y +"."+departamentos.getDepartamentos().get(y-1).getNombre());
                }
                //El usuario debe introducir el departamentro al que pertenece el empleado
                int departamentoElegido = libs.Leer.introduceEntero("Introduce el departamento que quieres para el empleado: " + empleado.getNombre());
                //Se introduce el departamento elegido al empleado
                if(departamentoElegido<=departamentos.getDepartamentos().size()){
                    departamentos.getDepartamentos().get(departamentoElegido-1).getEmpleadosDep().add(empleado);
                    salir = true;
                }else{
                    System.out.println("El número introducido no corresponde con un departamento");
                    salir=false;
                }
            }while(!salir);
        }
        return departamentos;
    }

    private static Departamentos leerDepartamentos() {
        Departamentos departamentos = new Departamentos();
        //Leeremos el archivo departamentos.xml con JAXB para pasarlo a una clase
        //Archivo a leer
        Path p = Path.of("src/main/resources/departamentos.xml");
        if(libs.CheckFiles.ficheroReadable(p)){
            //Creo las variables donde almacenar en mi código la información
            //Un contexto se utiliza cuando en nuestro código hemos cargado datos persistentes
            JAXBContext contexto = null;
            try{
                contexto = JAXBContext.newInstance(Departamentos.class);
                //Para pasar el codigo de XML -- Unmarshaller
                Unmarshaller unmarshaller = contexto.createUnmarshaller();
                departamentos = (Departamentos) unmarshaller.unmarshal(p.toFile());
                for(Departamento d: departamentos.getDepartamentos()){
                    d.setEmpleadosDep(new ArrayList<Empleado>());
                }
            }catch(JAXBException ex){
                System.out.println("El javaBean no sirve para este XML.");
            }
        }else{
            System.out.println("El fichero no se puede leer");
        }
        return departamentos;
    }

    private static ArrayList<Empleado> pedirEmpleados(ArrayList<Empleado> empleados) {
        Path p = Path.of("src/main/resources/empleados.csv");
        boolean salir = true;
        String nombre;
        Date antiguedad;
        int sueldo, añoNacimiento;
        do {
            //El usuario introduce todos los datos del empleado a añadir
            nombre = libs.Leer.introduceString("Introduce nombre del empleado");
            sueldo = libs.Leer.introduceEntero("Introduce sueldo del empleado");
            añoNacimiento = libs.Leer.introduceEntero("Introduce año de nacimiento del empleado");
            antiguedad = libs.Leer.introduceDate("Introduce antigüedad del empleado");
            //Se crea el nuevo empleado
            Empleado empleado = new Empleado(nombre, sueldo, añoNacimiento, antiguedad);
            //Se añado el empleado a la lista de todos los empleados
            empleados.add(empleado);
            //comprobamos si el fichero introducide se puede escribir
            if(libs.CheckFiles.ficheroEscribible(p)){
                //Escribimos en el fichero
                try(FileWriter writer = new FileWriter(p.toFile())){
                    //Recorremos todos los empleados para escribirlos en el csv
                    for(Empleado empleadoCSV : empleados){
                        //Creamos la linea con todos los datos del empleado para añadirla al csv
                        String linea = empleadoCSV.getNombre()+";"+empleadoCSV.getSueldo()+";"+
                                empleadoCSV.getAgno()+";"+empleadoCSV.getAntig();
                        //Escribimos la linea en el csv y saltamos la linea
                        writer.write(linea + "\n");
                    }
                    System.out.println("Escritura del empleado correcta");
                }catch(IOException e){
                    System.out.println("Error en la escritura del csv");
                }
            }else{
                System.out.println("No es posible escribir en este fichero");
            }
            //El usuario introducira true si quiere introducir más empleados o false si no quiere introducir más
            salir = libs.Leer.introduceBoolean("Introduce true si quiere seguir añadiendo empleados, de lo contrario introduzca false");
        } while (salir);
        return empleados;
    }
}
